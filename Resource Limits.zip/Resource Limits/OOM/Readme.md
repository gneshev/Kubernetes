We will use a "stress" image. We will set a Memory Limit of 100Mi, but we will tell the application to try and use 250Mi.



## Create a pod using the declarative way

Let’s now create a pod using a YAML file.

    kubectl create -f myapp.yaml

## Watch the status

    kubectl get pod memory-demo --watch

## Analyzing the Failure

    After a few seconds, the status will change from Running to OOMKilled. To see exactly why, use:

	kubectl describe pod memory-demo

	What to look for in the output:

	State: Terminated

	Reason: OOMKilled

	Exit Code: 137 (This specific code almost always indicates the process was killed by the OS/Kubernetes due to memory limits).
