Let’s test our local Kubernetes installation.

    kubectl cluster-info

