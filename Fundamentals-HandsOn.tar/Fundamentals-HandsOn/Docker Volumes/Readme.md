## Open a terminal and create a volume

    docker volume create myvol

## List the volumes

    docker volume ls

## Run a Nginx container that will use the volume

    docker run -d --name voltest --mount source=myvol,target=/app nginx:latest

## Connect to the instance

    docker exec -it voltest bash


## Create a file in the app folder
    cd app
    touch test.txt



## Stop and remove the container

    docker stop voltest
    docker rm voltest

## Run it again and see if the file still exists

    docker run -d --name voltest --mount source=myvol,target=/app nginx:latest
    docker exec -it voltest bash
    cd app
    ls

## Cleanup

    docker volume rm myvol
    docker stop voltest
    docker rm voltest
