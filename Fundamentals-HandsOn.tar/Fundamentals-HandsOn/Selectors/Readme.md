## Deploy the app

    kubectl apply -f myapp.yaml

## Deploy the service

    kubectl apply -f myservice.yaml

## Is the service connected to the pod?

If so, the enpoint will point to the pod IP address.  Get the IP address of the pod:

    kubectl get po -o wide

Then get the service endpoint.  The IP address should match.

    kubectl get ep myservice



## Edit the app YAML file

Change the **app** label to myapp2 and save the file

Deploy the change

    kubectl apply -f myapp.yaml

## Check the endpoint again

    kubectl get ep myservice


## Cleanup

    kubectl delete -f myservice.yaml
    kubectl delete -f myapp.yaml
